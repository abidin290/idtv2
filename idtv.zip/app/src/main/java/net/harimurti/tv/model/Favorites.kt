package net.harimurti.tv.model

class Favorites {
    var channels = ArrayList<Channel>()
}